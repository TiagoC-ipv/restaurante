const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());


app.use((req, res, next) => {
  const agora = new Date().toLocaleString();
  console.log(`[${agora}] New request has been made: ${req.method} ${req.url}`);
  next();
});


const authMiddleware = require("./middleware/authMiddleware.js");
const User = require("./Models/user.js");


const pratos = require('./Controllers/menu_do_dia');

const PORT = 4000;


mongoose.connect("mongodb://localhost:27017/restaurante")
  .then(() => {
    console.log("Ligado ao MongoDB com Mongoose!");

    app.post("/register", async (req, res) => {
      try {
        const { username, password } = req.body;
        const user = await User.create({ username, password });
        res.json(user);
      } catch (err) {
        res.status(400).json({ erro: "Erro ao criar utilizador: " + err.message });
      }
    });

    // Rota protegida (teste da ficha)
    app.get("/private", authMiddleware, (req, res) => {
      res.send("Acesso autorizado! Bem-vindo, " + req.user.username);
    });

  
    app.use("/pratos", pratos);

    app.use((err, req, res, next) => {
      res.status(400).json({ erro: "Erro inesperado: " + err.message });
    });

    app.listen(PORT, () => {
      console.log("Restaurante QuintaDosCabrais a correr na porta", PORT);
    });
  })
  .catch(err => console.error("Erro ao ligar ao MongoDB:", err));
