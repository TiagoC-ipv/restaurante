const express = require('express');
// const { connectDB } = require('./shared/db');  // Código antigo (comentado)
const mongoose = require('mongoose');

const app = express();
app.use(express.json());

app.use(function (req, res, next) {
  const agora = new Date().toLocaleString();
  console.log(`[${agora}] New request has been made: ${req.method} ${req.url}`);
  next();
});

const PORT = 4000;

mongoose.connect("mongodb://localhost:27017/restaurante", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log("Ligado ao MongoDB com Mongoose!");

  const pratos = require('./Controllers/menu_do_dia');
  app.use("/pratos", pratos);

  app.use((err, req, res, next) => {
    res.status(400).json({ erro: "Erro inesperado: " + err.message });
  });

  app.listen(PORT, () => {
    console.log("Restaurante QuintaDosCabrais");
  });
})
.catch(err => console.error("Erro ao ligar ao MongoDB:", err));
