const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost:27017';
const dbName = "Ficha_2";
let db;
 
async function connectDB() {
  const client = new MongoClient(url);
  await client.connect();
  db = client.db(dbName);
  console.log('Conectado ao MongoDB');
}

function getDB() {
  return db;
}
module.exports = { connectDB, getDB };

 